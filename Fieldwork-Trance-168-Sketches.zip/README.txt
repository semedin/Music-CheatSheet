FIELDWORK / TRANCE

168 arranged MIDI sketches: 12 supplied melodies + 16 original studies, each with six treatments.
Each file contains melody, suggested voiced chords, bass, drums and tempo metadata.
Chords are creative harmonizations, not recovered original parts. The original treatment retains source melody notes, timing and velocities.
Source files have no tempo marker; style tempos are suggestions. All files use the original pitch and sustained chords.
Transpose, change tempo and switch chord motion in trance.html, then export the current idea.
Artist perspectives are original writing exercises, not transcriptions or artist presets.
MIDI contains notes, not audio or effects. Assign your own instruments in your DAW.
C4 = MIDI 60. Kick = 36, clap = 39, closed hat = 42.
